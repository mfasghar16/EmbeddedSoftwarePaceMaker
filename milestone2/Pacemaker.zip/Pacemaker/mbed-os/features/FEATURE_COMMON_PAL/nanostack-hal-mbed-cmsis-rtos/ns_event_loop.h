/*
 * Copyright (c) 2016 ARM Limited, All Rights Reserved
 */

#ifdef __cplusplus
extern "C" {
#endif

void ns_event_loop_thread_create(void);
void ns_event_loop_thread_start(void);

#ifdef __cplusplus
}
#endif

