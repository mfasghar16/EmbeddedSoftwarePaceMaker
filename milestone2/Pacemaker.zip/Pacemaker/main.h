void sense_interrupt(void);
void wait_VRP_timer(void);

void pace_timer(void);

void heartbeat_monitor(void);

void reset_statistics(void);

void poll_inputs(void);

void send_message(float i, int j, int k);

bool init_network();