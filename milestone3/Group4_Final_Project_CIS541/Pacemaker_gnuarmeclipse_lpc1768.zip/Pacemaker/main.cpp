#include "mbed.h"
#include "rtos.h"
#include "main.h"
#include "MQTTNetwork.h"
#include "MQTTmbed.h"
#include "MQTTClient.h"
#include "ESP8266Interface.h"

// consts
#define VRP 320
#define LRI 1000
#define HRI 1200

#define WINDOW 60000
#define PERIOD 10000

#define POLLING_TIME 100

// for debugging
Serial pc(USBTX, USBRX);

DigitalOut led1(p13);
DigitalOut led2(p18);
DigitalIn sensed(p11);
DigitalOut paceOut(p16);

// set default rateInterval
int rateInterval = LRI;

// guards
bool waitVRP = false;
bool stopVRP = true;
bool paceStarted = false;
bool led1On = false;
bool led2On = false;

// statistics
volatile int senseCount = 0;
volatile int paceCount = 0;
volatile int totalPaceCount = 0;
volatile int totalHeartBeats = 0;
volatile float  rate = 0.0;
volatile int paceMode = 0;
volatile int rateMode = 0;

// statistic semapgores
Semaphore paceSemaphore(1);
Semaphore senseSemaphore(1);
Semaphore heartbeatGuard(1);
Semaphore guardLock(1);

// timer to simulate waitVRP state 
RtosTimer waitVRPTimer(wait_VRP_timer);

// timer to simulate waitinterval state
RtosTimer paceTimer(pace_timer);

// timers for statistics
RtosTimer monitor(heartbeat_monitor);
RtosTimer resetStats(reset_statistics);

// polling timer to check if heart has sent a 'sense' signal
RtosTimer pollSense(poll_inputs);

//---------- MQTT -----------
int arrivedcount = 0;
ESP8266Interface wifi(p28, p27);
MQTTNetwork* mqttNetwork;
MQTT::Client<MQTTNetwork, Countdown>* client;

bool init_network()
{
    int network_conn = 0;
    // set your own values 
    wifi.set_credentials(MBED_CONF_APP_WIFI_SSID, MBED_CONF_APP_WIFI_PASSWORD);
    pc.printf("Connecting:...\n\r");
    network_conn = wifi.connect(); 
    pc.printf("Connection code was %d \r\n\r\n", network_conn);

    
    char* uuid = "26013f37-10000015100000161000001710000018";
    const char* hostname = "35.196.225.7";
    int port = 1883;
    
    mqttNetwork = new MQTTNetwork(&wifi);
    client = new MQTT::Client<MQTTNetwork, Countdown>(*mqttNetwork);
    
    pc.printf("Connecting to %s:%d\r\n", hostname, port);
    int rc = mqttNetwork->connect(hostname, port);
    
    if (rc != 0){
        pc.printf("rc from TCP connect is %d\r\n", rc);
    }
    
    MQTTPacket_connectData data = MQTTPacket_connectData_initializer;
    data.MQTTVersion = 3;
    data.clientID.cstring = uuid;
    data.username.cstring = "mbed";
    data.password.cstring = "homework";
    
    if ((rc = client->connect(data)) != 0)
        pc.printf("rc from MQTT connect is %d\r\n", rc);

    
    return true;
}

// sends heart rate data to MQTT broker
void send_message(float rate, int paceMode, int rateMode) {
    printf("send message/n/r");
    MQTT::Message message;
    int rc = 0;

    // load up the message 
    char buf[80];

    sprintf(buf, "%f,%d,%d", rate, paceMode, rateMode);

    message.qos = MQTT::QOS2;
    message.retained = false;
    message.dup = false;
    message.payload = (void*)buf;
    message.payloadlen = strlen(buf)+1;


    char topic_send[80];
    sprintf(topic_send, "cis541/hw-mqtt/26013f37-10000015100000161000001710000018/data");

    rc = client->publish(topic_send, message);
    client->yield(10);
    
    pc.printf("rc for topic sent is %d\n\r", rc);

    
}

// method checks if the heart mbed has sent a sense signal
void poll_inputs() {
    if (sensed) {
        sense_interrupt();
    } 
}

// method calculates heartRate for a given window (called every PERIOD seconds)
// and sends data to MQTT server and signals on the mbed
void heartbeat_monitor() {
    printf("Moniter Checking Status...\n\r");
    heartbeatGuard.wait();
    printf("%d\n\r", totalHeartBeats);
    rate = (totalHeartBeats*60.0) / (WINDOW / 1000);
    heartbeatGuard.release();
    
    // markers to record alert to database

    
    // pace maker needed too often, send alarm
    if (paceCount > senseCount) {
        printf("Pace maker is in use frequently...\n\r");
        // signal alarm on mbed
        led1On = true;
        paceMode = 1;
        //send 
    }
    
    // heart is beating too fase (1.8 is the maximum pulse width)
    float URL = WINDOW / 1800;
    printf("Rate: %f    URL: %f", rate, URL);
    if (rate > URL) {
        printf("Heart is beating too quickly...\n\r");
        led2On = true;
        rateMode = 1;
    }
   // send_message(rate, paceMode, rateMode);
}
// method resets stats
void reset_statistics() {
   printf("Statistics Reset\n\r");
    heartbeatGuard.wait();
    totalHeartBeats = 0;
    heartbeatGuard.release();
    
    paceSemaphore.wait();
    paceCount = 0;
    paceSemaphore.release();
    
    senseSemaphore.wait();
    senseCount = 0;
    senseSemaphore.release();
}

// callback for if the heart sends a sense signal (i.e. beating normally)
void sense_interrupt() {
   printf("Sense Detected...\n\r");
    // only process interrupts while not in VRP and the pace signal has not been sent
    if (!waitVRP) {
        printf("Sense executed...\n\r");
        // stop the pace timer
        paceTimer.stop();
        waitVRP = true;
        rateInterval = HRI;
        waitVRPTimer.start(VRP);
        
        senseSemaphore.wait();
        senseCount++;
        senseSemaphore.release();
    }
    // start VRP timer
}

// meethod called when pace timer has expired (maximum wait time exceeded, 
// need to 'pace' the heart)
void pace_timer() {
    printf("Pace Detected...\n\r");
    // function called, meaning must send pace signal to heart
    if (!waitVRP) {
       printf("Pace Executed...\n\r");
       // printf("pace_timer() executed\n");
        paceStarted = true;
        paceOut = 1;
        
        // send the signal
        rateInterval = LRI;
        waitVRPTimer.start(VRP);
        
        // update statistics
        paceSemaphore.wait();
        paceCount++;
        totalPaceCount++;
        paceSemaphore.release();
        
    }
}
// method called when VRP has expired, start of an new heart cycle
void wait_VRP_timer() {
    printf("Heart Beat Event in Pacemaker...\n\r");
    waitVRP = false;
    paceStarted = false;
    paceTimer.start(rateInterval - VRP);
    guardLock.wait();
    stopVRP = true;
    guardLock.release();
    
    heartbeatGuard.wait();
    totalHeartBeats++;
    heartbeatGuard.release();
}


int main() {
    // init_network();

    paceTimer.start(rateInterval);
    monitor.start(PERIOD);
    resetStats.start(WINDOW);
    pollSense.start(POLLING_TIME);
    
    
    while(1) {
        if (stopVRP) {
            waitVRPTimer.stop();
            guardLock.wait();
            stopVRP = false;
            guardLock.release();
            paceOut = 0;
            // flash alarms if they are on
            if (led1On) {
                printf("Alarm One Flashed...\n\r");
                led1 = 1;
                Thread::wait(1000);
                led1 = 0;
                led1On = false;
            }
            if (led2On) {
                printf("Alarm Two Flashed...\n\r");
                led2 = 1;
                Thread::wait(1000);
                led2 = 0;
                led2On = false;
            }   
        }
        
       // send_message(rate, paceMode, rateMode);
        
        
    }
}
