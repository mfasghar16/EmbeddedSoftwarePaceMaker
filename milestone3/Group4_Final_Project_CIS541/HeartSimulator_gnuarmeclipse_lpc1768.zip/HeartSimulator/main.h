void heartBeat(void);

void handlePace(void);

void poll_pace(void);