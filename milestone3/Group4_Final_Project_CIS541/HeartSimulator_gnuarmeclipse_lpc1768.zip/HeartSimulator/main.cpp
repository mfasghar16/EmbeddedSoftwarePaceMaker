/*
Simulates the beating of a heart. A heart beats after a time t within the 
range of (t + min) - (t + maxx)
*/

#include "mbed.h"
#include "rtos.h"
#include "main.h"

#define MIN 250
#define MAX 1700
#define POLLING_INTERVAL 100

Serial pc(USBTX, USBRX);

DigitalIn pace(p17);
DigitalOut beat(p16);

bool beatAgain = true;
RtosTimer heart(heartBeat);
RtosTimer pollPace(poll_pace);
Semaphore heartGuard(1);

// method returns a random beat interval between min and max
int getHeartBeatTime() {
    return rand()%(MAX - MIN + 1) + MIN;
}

// polling method that checks to see if the pacemaker has sent a signal 
// every POLLING_INTERVAL ms
void poll_pace() {
    if (pace) {
        handlePace();
    }
}
 
// method that sends a signal to the pacemaker that the heart beat normally
void heartBeat() {
    beat = 1;
    heartGuard.wait();
    beatAgain = true;
    heartGuard.release();
    pc.printf("Sense out...\n\r");
}


// method handles the event of a pace. 'beats' the heart immediately
void handlePace() {
    heart.stop();
    heartGuard.wait();
    beatAgain = true;
    heartGuard.release();
    pc.printf("Pace Detected...\n\r");
}



int main() {
    pollPace.start(POLLING_INTERVAL);
    // this loop simulates the heart rate, beatAgain is true only after a pace
    // event or the heart interval has expired
    while(1) {
        if (beatAgain) {
            pc.printf("Beat...\n\r");
            int time = getHeartBeatTime();
            heart.start(time);
            
            heartGuard.wait();
            beatAgain = false;
            heartGuard.release();
            
            // wait to clear signal
            Thread::wait(150);
            beat = 0;
        }
    }
}
